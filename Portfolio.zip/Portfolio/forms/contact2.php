<?php
  // Get the form data
  $name = $_POST['name'];
  $email = $_POST['email'];
  $subject = $_POST['subject'];
  $message = $_POST['message'];

  // Set up the email headers and message
  $to = "swathykrishnacs2020@gmail.com"; // Replace with your email address
  $headers = "From: $name <$email>" . "\r\n";
  $headers .= "Reply-To: $email" . "\r\n";
  $headers .= "Content-Type: text/html; charset=UTF-8" . "\r\n";
  $message = "<h3>$subject</h3><p>$message</p>";

  // Send the email
  if (mail($to, $subject, $message, $headers)) {
    echo "Email sent successfully.";
  } else {
    echo "Email failed to send.";
  }
?>